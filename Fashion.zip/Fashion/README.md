<h1 align = "center">Fashion Avenue🛒</h1>


<p align="center">Refresh Your Wardrobe!🛍️ 
 <p align="center">
Here's our Team very own custom website relating to fashion.
 </p>
 
 
 <p align="center">
Online Clothing Fashion is an e-commerce website that offers a wide range of trendy and stylish clothing for men, women, and children. The website was built using HTML and CSS, which allowed for the creation of a user-friendly interface that is easy to navigate.

The homepage of the website features a simple and elegant design that showcases the latest arrivals and popular items. The navigation menu is located at the top of the page, allowing customers to easily browse through the different categories of clothing available on the website.

Though you can find some familiar images used in the website taken from various sources, but the purpose is to only make it more aesthetic.

 </p>

